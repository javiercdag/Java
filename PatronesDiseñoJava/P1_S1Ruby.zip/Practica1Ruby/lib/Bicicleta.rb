public
class Bicicleta

	public

	def initialize()
		@idBicicleta
		@retirarse #true si la bicicleta se retirará tempranamente, false en otro caso
	end
  
  def correr() # Solo duran 5-10 segundos porque al no haber concurrencia si no sería desorbitado
    puts "(+)Comienza la bicicleta #{@idBicicleta}"
    sleep(5) # primera mitad de una carrera, toda bicicleta lo soporta.
    if (@retirarse)
      puts "(-)La bicicleta #{@idBicicleta} se retira"
    else
      sleep(5) # segunda mitad de una carrera, solo para las bicicletas que no se retiran
      puts "(END)La bicicleta #{@idBicicleta} ha llegado"
    end
  end
  
  def clone()
    
  end
  
end
