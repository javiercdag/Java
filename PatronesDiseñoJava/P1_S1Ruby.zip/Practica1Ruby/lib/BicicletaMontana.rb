require('./Bicicleta.rb');

public
class BicicletaMontana < Bicicleta
  @@contadorBicicletas = 0
  
	public
	def initialize(idBicicleta, retirarse)
		@idBicicleta = idBicicleta
    @retirarse = retirarse
	end

	def clone() # metodo clonador para el prototipo
    @@contadorBicicletas = @@contadorBicicletas + 1;
    return BicicletaMontana.new(@idBicicleta + @@contadorBicicletas, @retirarse)
  end
  
  def retirarse=(retirarse) # como ahora clonamos bicicletas, queremos poder editarlas
    @retirarse = retirarse
  end
end
