public
class Carrera

	public
	def empezar() 
    puts "Comienza la carrera"
    for i in @bicicletas
      i.correr # da el pistoletazo de salida para la bicicleta i
    end
	end

	def initialize()
		@bicicletas # participantes de la carrera
		@numBicicletas
	end
  
  def clone()
    
  end

end
