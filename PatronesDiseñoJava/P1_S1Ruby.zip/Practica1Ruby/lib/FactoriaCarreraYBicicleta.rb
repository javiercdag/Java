require('./Carrera.rb');
require('./Bicicleta.rb');

public
class FactoriaCarreraYBicicleta

	public
	def crearCarrera(numBicicletas)
    
	end

	def crearBicicleta(bicicleta)
    
	end

end
