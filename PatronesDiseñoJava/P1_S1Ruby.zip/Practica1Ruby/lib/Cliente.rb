require_relative "FactoriaCarretera.rb"
require_relative "FactoriaMontana.rb"

public
class Cliente

	public
  
  def self.main()
    puts "Elige el numero de participantes para la carrera en carretera:"
        
    numBicicletas = gets.to_i
    
    # Creación de las factorias
    fcarretera = FactoriaCarretera.new
    fmontana = FactoriaMontana.new
        
    carreraC = fcarretera.crearCarrera(numBicicletas)
    carreraC.empezar # comienza la carrera de carretera
        
    puts "Elige el numero de participantes para la carrera en montana:"
        
    numBicicletas = gets.to_i

    carreraM = fmontana.crearCarrera(numBicicletas)
    carreraM.empezar # comienza la carrera de montaña
    
    return(0)
  end
  
	def initialize()

	end
end

Cliente.main()

