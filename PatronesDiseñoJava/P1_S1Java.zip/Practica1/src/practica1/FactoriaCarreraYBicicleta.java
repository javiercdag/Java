package practica1;

public interface FactoriaCarreraYBicicleta {

	public Carrera crearCarrera(int numBicicletas);
	public Bicicleta crearBicicleta(int numBicicleta, boolean retirarse);

}