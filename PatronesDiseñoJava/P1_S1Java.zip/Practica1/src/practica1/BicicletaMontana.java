package practica1;

public class BicicletaMontana extends Bicicleta {
    
    public BicicletaMontana(int idBicicleta, boolean retirarse) {
        this.idBicicleta = idBicicleta;
        this.retirarse = retirarse;
    }
    
}