package practica1;

public class BicicletaCarretera extends Bicicleta {

    public BicicletaCarretera(int idBicicleta, boolean retirarse) {
        this.idBicicleta = idBicicleta;
        this.retirarse = retirarse;
    }
    
}
